# Installation Guide

## Prerequisites
- Python 3.10+ with `pip`
- Node.js 18+ with `npm` (only needed if you rebuild Tailwind CSS)
- Google Gemini API key (set as an env var)
- Optional: ngrok account if you plan to expose the app publicly

## 1) Setup Python Environment (recommended)
```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
```

## 2) Install Python Dependencies
```bash
pip install -r requirements.txt
```

## 3) Install Node Dependencies (for CSS builds)
```bash
npm install
```

## 4) Build CSS Assets
- Use the prebuilt `dist/output.css` or rebuild:
```bash
npm run build-css-prod          # one-time build
# or
npm run build-css               # watch mode during development
```

## 5) Configure Environment
Set your Gemini API key so AI endpoints work:
```bash
export GEMINI_API_KEY="your-key"    # macOS/Linux
# Windows (PowerShell)
$env:GEMINI_API_KEY="your-key"
```
You can also use `API_KEY` as the variable name.

## 6) Run the Servers
- Start both Flask (port 5002) and WebSocket (port 8765) together:
```bash
python start_servers.py
```
- Or run separately:
```bash
python app.py                  # Flask API + frontend
python collaboration_server.py # WebSocket collaboration server
```


